
public enum StatusTest {
	
		PASSED,
		FAILED,
		BLOCKED
}