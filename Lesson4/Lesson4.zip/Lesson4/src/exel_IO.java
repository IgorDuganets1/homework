import jxl.Cell;
import jxl.Sheet;
import jxl.format.Colour;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class exel_IO implements InputOutput {

	@Override
	public void tableColumnsFormat(WritableSheet outputsheet) {
		int col = 1;
 	    int widthInChars = 55;
 	    outputsheet.setColumnView(col, widthInChars);
 	    
 	    int col2 = 2;
	    int widthInChars2 = 10;
	    outputsheet.setColumnView(col2, widthInChars2);
		
	}

	@Override
	public void tableHeader(WritableSheet outputsheet) throws RowsExceededException, WriteException {
		
		WritableFont times12font = new WritableFont(WritableFont.ARIAL, 12, WritableFont.BOLD, false); 
 		WritableCellFormat times12format = new WritableCellFormat (times12font); 
		
		Label label = new Label(0, 0, "Number",times12format);
 		outputsheet.addCell(label); 
 		Label label2 = new Label(1, 0, "Test case name",times12format);
 		outputsheet.addCell(label2); 
 		Label label3 = new Label(2, 0, "Result",times12format);
 		outputsheet.addCell(label3); 
		
	}

	@Override
	public void testCounters(int p, int f, int b) {
		System.out.println("tests PASSED :" + p);
 		System.out.println("tests FAILED :" + f);
 		System.out.println("tests FAILED :" + b);
		
	}

	@Override
	public void exelReport(int i, String testNumber, String testCaseName,WritableSheet outputsheet) throws RowsExceededException, WriteException {
		Label labelTestNumber = new Label(0, i, testNumber);
    	  outputsheet.addCell(labelTestNumber);
    	  Label labelTestCaseName = new Label(1, i, testCaseName);
  	      outputsheet.addCell(labelTestCaseName);
        }

	protected static WritableCellFormat getCellFormat(Colour colour) throws WriteException {
	    WritableFont cellFont = new WritableFont(WritableFont.ARIAL, 12);
	    WritableCellFormat cellFormat = new WritableCellFormat(cellFont);
	    cellFormat.setBackground(colour);
	    return cellFormat; 
	  }
}
