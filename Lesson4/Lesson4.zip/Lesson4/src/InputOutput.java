import jxl.Sheet;
import jxl.write.WritableSheet;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public interface InputOutput {

	public void tableColumnsFormat(WritableSheet outputsheet);
	public void tableHeader(WritableSheet outputsheet) throws RowsExceededException, WriteException;
	public void testCounters (int p,int f, int b);
	public void exelReport(int i, String testNumber, String testCaseName,WritableSheet outputsheet) throws RowsExceededException, WriteException;

}
