import java.io.File;
import java.io.IOException;
import java.sql.*;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.format.Colour;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

import java.util.*;

public class database extends exel_IO {

	public static void main(String []args)throws IOException, WriteException, SQLException, BiffException {
        String user = "root";//����� ������������
        String password = "root";//������ ������������
        String driver = "com.mysql.jdbc.Driver";//��� ��������
        String url = "jdbc:mysql://localhost:3306/test";//URL �����
        
        try {
             Class.forName(driver);//������������ �������
        } catch (ClassNotFoundException e) {
             // TODO Auto-generated catch block
             e.printStackTrace();
        }
        Connection c = null;//���������� � ��
       try{
             c = DriverManager.getConnection(url, user, password);//��������� ���������� � ��
             Statement st = c.createStatement();//������� ������
             
            Workbook workbook = Workbook.getWorkbook(new File("checklist.xls"));
     		Sheet sheet = workbook.getSheet(0);
         
     		WritableWorkbook outputworkbook = Workbook.createWorkbook(new File("output.xls")); 
     		WritableSheet outputsheet = outputworkbook.createSheet("Test Result", 0); 
     		
     		InputOutput io=new exel_IO();
     		
     		io.tableHeader(outputsheet);
       		io.tableColumnsFormat(outputsheet);
     		
     		Map<String,StatusTest> hm = new HashMap<String,StatusTest>();
     		
           	int p=0,f=0,b=0; // counters
       	   
     	   for (int i=1; i<sheet.getRows();i++)
     		{
     			Cell cell1 = sheet.getCell(0, i);
     			String testNumber=cell1.getContents();
     			Cell cell2 = sheet.getCell(1, i);
     			String testCaseName=cell2.getContents();
     			Cell cell3 = sheet.getCell(2, i);
     			String query = cell3.getContents();
     			Cell cell4 = sheet.getCell(3, i);
     			String expected_result=cell4.getContents();
     		      			
     			Cell cell5 = sheet.getCell(4, i);
     			String result_column=cell5.getContents();     		 			
     			
     		 	String result=null;
  	try{	
     			ResultSet rs = st.executeQuery(query);//��������� ������ � ��, ��������� � ���������� rs
                while(rs.next()){
                       result=rs.getString(result_column);//��������������� ��� ������ ������ ������� �������� �� ������� ColumnName
                                       
                } 
     
                String resultStatus;
          
               if (result.equals(expected_result)){
                  hm.put(testNumber, StatusTest.PASSED);
                  resultStatus="PASSED";
                  Label labelResultStatus = new Label(2, i, resultStatus, getCellFormat(Colour.GREEN));
            	  outputsheet.addCell(labelResultStatus);
            	  p++;}
                	  
                  else {
                  hm.put(testNumber, StatusTest.FAILED);
                  resultStatus="FAILED";
                  Label labelResultStatus = new Label(2, i, resultStatus, getCellFormat(Colour.RED));
            	  outputsheet.addCell(labelResultStatus);
            	  f++;            	  }
     		
     		} catch(Exception e){
     	          e.printStackTrace();
     	        hm.put(testNumber, StatusTest.BLOCKED);
                String resultStatus2="BLOCKED";
                Label labelResultStatus = new Label(2, i, resultStatus2, getCellFormat(Colour.ORANGE));
          	  	outputsheet.addCell(labelResultStatus);
          	  	b++;     		}
	              
                  io.exelReport(i, testNumber, testCaseName, outputsheet);
                        	  
     		}
		
       		Set<Map.Entry<String, StatusTest>> set = hm.entrySet();
     		for (Map.Entry<String, StatusTest> me : set) {
     			System.out.print(me.getKey() + ": ");
     			System.out.println(me.getValue());}
     		
       		io.testCounters(p, f, b);
     		
     		workbook.close();
     		   		
     		outputworkbook.write();
    		outputworkbook.close(); 
      }
         finally{
           try {
                  if(c != null)
                  c.close();
             } catch (SQLException e) {
                     e.printStackTrace();
             }
        }
	}
}
